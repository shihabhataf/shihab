<?php
$servername = "sql204.infinityfree.com";
$username = "if0_36969144";
$password = "2hRz89ldqZESk";
$dbname = "if0_36969144_likes";
$port = 3306;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'];

$sql = "SELECT has_liked FROM user_likes WHERE user_id='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $conn->query("INSERT INTO user_likes (user_id, has_liked) VALUES ('$user_id', true)");
    $conn->query("UPDATE likes SET count = count + 1");
}

$sql = "SELECT count FROM likes";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$count = $row['count'];

echo json_encode(['count' => $count]);

$conn->close();
?>
