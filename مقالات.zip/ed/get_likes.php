<?php
$servername = "sql204.infinityfree.com";
$username = "if0_36969144";
$password = "2hRz89ldqZESk";
$dbname = "if0_36969144_likes";
$port = 3306;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_GET['user_id'];
$sql = "SELECT count FROM likes";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$count = $row['count'];

$sql = "SELECT has_liked FROM user_likes WHERE user_id='$user_id'";
$result = $conn->query($sql);
$hasLiked = $result->num_rows > 0 ? $result->fetch_assoc()['has_liked'] : false;

echo json_encode(['count' => $count, 'hasLiked' => $hasLiked]);

$conn->close();
?>
