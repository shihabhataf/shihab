document.querySelector('.fa-bars').addEventListener('click', ()=> {
    document.querySelector('.link').classList.toggle('active')
})