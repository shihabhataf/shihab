<?php
$servername = "sql204.infinityfree.com";
$username = "if0_36969144";
$password = "2hRz89ldqZESk";
$dbname = "if0_36969144_like";

// الاتصال بقاعدة البيانات
$conn = new mysqli($servername, $username, $password, $dbname);

// تحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// استلام بيانات المتابعة من الطلب
$data = json_decode(file_get_contents('php://input'), true);
$followers = intval($data['followers']);

// تحديث عدد المتابعين في قاعدة البيانات
$sql = "UPDATE followers_table SET followers_count = ? WHERE user_id = 1"; // عدل user_id حسب حاجتك
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $followers);

$response = [];
if ($stmt->execute()) {
    $response['success'] = true;
} else {
    $response['success'] = false;
}

$stmt->close();
$conn->close();

// إرسال الرد كـ JSON
header('Content-Type: application/json');
echo json_encode($response);
?>