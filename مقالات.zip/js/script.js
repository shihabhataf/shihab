function openNav() {
    document.getElementById("mySidebar").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidebar").style.width = "0px";
}
document.addEventListener('DOMContentLoaded', function() {
            function loadArticles(containerId, articles) {
                const articlesContainer = document.getElementById(containerId);

                articles.forEach(article => {
                    fetch(article)
                        .then(response => response.text())
                        .then(html => {
                            const doc = new DOMParser().parseFromString(html, 'text/html');
                            const title = doc.querySelector('h2') ? doc.querySelector('h2').innerText : 'عنوان غير متوفر';
                            const imgElement = doc.querySelector('img#img');
                            const imgSrc = imgElement ? imgElement.src : 'https://via.placeholder.com/800x400';
                            const content = doc.querySelector('main') ? doc.querySelector('main').innerText : 'محتوى غير متوفر';

                            const articleDiv = document.createElement('div');
                            articleDiv.className = 'article-summary';
                            articleDiv.dataset.title = title;
                            articleDiv.dataset.content = content;
                            articleDiv.dataset.imgSrc = imgSrc;

                            articleDiv.innerHTML = `<a class="image-container" href="${article}">
                            <img class="img" src="${imgSrc}" alt="صورة المقال" onerror="this.src='https://via.placeholder.com/800x400';">
                            <div class="gradient-overlay"></div>
                            <h3 style="text-align: center;">${title}</h3>
                            <p>${content.substring(0, 100)}</p></a>
                        `;

                            articlesContainer.insertBefore(articleDiv, articlesContainer.firstChild);
                        })
                        .catch(error => console.error('Error loading article:', error));
                });
            }

            const mocArticles = [
                '../boldan/boldan3.html',
                '../shakh/shakh1.html',
                '../tecno/tecno1.html',
                '../reyath/reyath1.html'
            ];
            loadArticles('articlesContainer', mocArticles);

            const boldanArticles = [
                '../boldan/boldan1.html',
                '../boldan/boldan2.html',
                '../boldan/boldan3.html',
                '../boldan/boldan4.html',
                '../boldan/boldan5.html',
                '../boldan/boldan6.html',
                '../boldan/boldan7.html',
                '../boldan/boldan8.html',
                '../boldan/boldan9.html',
                '../boldan/boldan10.html',
            ];
            loadArticles('articlesContainer1', boldanArticles);

            const tecnoArticles = [
                '../tecno/tecno1.html',
                '../tecno/tecno2.html',
                '../tecno/tecno3.html',
                '../tecno/tecno4.html',
                '../tecno/tecno5.html'
            ];
            loadArticles('articlesContainer2', tecnoArticles);

            const reyathArticles = [
                '../reyath/reyath1.html',
                '../reyath/reyath2.html',
                '../reyath/reyath3.html',
                '../reyath/reyath4.html',
                '../reyath/reyath5.html'
            ];
            loadArticles('articlesContainer3', reyathArticles);

            const shakhArticles = [
                '../shakh/shakh1.html',
                '../shakh/shakh2.html',
                '../shakh/shakh3.html',
                '../shakh/shakh4.html',
                '../shakh/shakh5.html'
            ];
            loadArticles('articlesContainer6', shakhArticles);

            const adbArticles = [
                '../adb/adb1.html',
                '../adb/adb2.html',
                '../adb/adb3.html',
                '../adb/adb4.html',
                '../adb/adb5.html',
            ];
            loadArticles('articlesContainer4', adbArticles);

            const newsArticles = [
                '../news/news1.html',
                '../news/news2.html',
                '../news/news3.html',
            ];
            loadArticles('articlesContainer5', newsArticles);

            const ed1Articles = [
                '../boldan/boldan1.html',
                '../boldan/boldan2.html',
                '../boldan/boldan3.html',
                '../boldan/boldan4.html',
                '../reyath/reyath1.html',
                '../tecno/tecno1.html',
                '../shakh/shakh1.html',
                '../shakh/shakh2.html',
            ];
            loadArticles('articlesContainerEd1', ed1Articles);

            const resultsPerPage = 30;
            let currentPage = 1;
            let totalResults = 0;
            let filteredArticles = [];

            document.getElementById('searchInput').addEventListener('input', debounce(function() {
                const filter = this.value.toLowerCase();
                const articles = document.querySelectorAll('.article-summary');
                const results = document.getElementById('searchResults');
                results.innerHTML = '';
                filteredArticles = [];
                totalResults = 0;
                currentPage = 1;

                if (filter.trim() === '') {
                    return;
                }

                articles.forEach(article => {
                    const title = article.dataset.title.toLowerCase();
                    const content = article.dataset.content.toLowerCase();

                    let startIndex = 0;
                    while ((startIndex = content.indexOf(filter, startIndex)) !== -1) {
                        filteredArticles.push({
                            article: article,
                            startIndex: startIndex
                        });
                        totalResults++;
                        startIndex += filter.length;
                    }
                });

                updateResults();
            }, 300));

            function updateResults() {
                const results = document.getElementById('searchResults');
                results.innerHTML = '';
                const resultsCount = document.getElementById('resultsCount');
                resultsCount.innerText = `عدد النتائج: ${totalResults}`;

                const start = (currentPage - 1) * resultsPerPage;
                const end = Math.min(totalResults, currentPage * resultsPerPage);

                for (let i = start; i < end; i++) {
                    const { article, startIndex } = filteredArticles[i];
                    const content = article.dataset.content;
                    const title = article.dataset.title;
                    const imgSrc = article.dataset.imgSrc;
                    const filter = document.getElementById('searchInput').value.toLowerCase();

                    const startSnippetIndex = Math.max(0, startIndex - 30);
                    const endSnippetIndex = Math.min(content.length, startIndex + filter.length + 100);
                    const snippet = content.substring(startSnippetIndex, endSnippetIndex)
                        .replace(new RegExp(filter, 'gi'), match => `<strong style="color: #87460D ">${match}</strong>`);

                    const link = document.createElement('a');
                    link.href = article.querySelector('a').getAttribute('href');
                    link.className = 'search-item';
                    link.innerHTML = `
                        <div class="eq">
                            <img src="${imgSrc}" alt="صورة المقال" class="img" style="width: 100%; height: auto;">
                            <div>
                            <h3>${title}</h3>
                            <br>
                            <p>...${snippet}...</p>
                            </div>
                        </div>
                    `;
                    results.appendChild(link);
                }

                const paginationControls = document.createElement('div');
                paginationControls.className = 'pagination-controls';

                const prevButton = document.createElement('button');
                prevButton.innerText = 'الصفحة السابقة';
                prevButton.onclick = () => {
                    if (currentPage > 1) {
                        currentPage--;
                        updateResults();
                    }
                };
                paginationControls.appendChild(prevButton);

                const pageNumber = document.createElement('span');
                pageNumber.innerText = `الصفحة ${currentPage}`;
                paginationControls.appendChild(pageNumber);

                const nextButton = document.createElement('button');
                nextButton.innerText = 'الصفحة التالية';
                nextButton.onclick = () => {
                    currentPage++;
                    updateResults();
                };
                paginationControls.appendChild(nextButton);

                results.appendChild(paginationControls);
            }
        });

        function debounce(func, wait) {
            let timeout;
            return function() {
                const context = this,
                    args = arguments;
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(context, args), wait);
            };
        }
function sharePage() {
            const pageTitle = document.title;
            const pageUrl = window.location.href;
            const firstH2Text = document.querySelector('h2').innerText;
            if (navigator.share) {
                navigator.share({
                    title: pageTitle,
                    text: 'اقراء المقالة الان بعنوان ' + firstH2Text,
                    url: 'رابط الصفحة ' + pageUrl
                }).then(() => {
                    console.log('تمت المشاركة بنجاح');
                }).catch((error) => {
                    console.error('حدث خطأ أثناء المشاركة:', error);
                });
            } else {
                alert('ميزة المشاركة غير مدعومة في هذا المتصفح.');
            }
        }
        